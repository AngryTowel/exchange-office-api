<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\ClassBindingProvider::class,
    App\Providers\ModelObserversProvider::class,
];
