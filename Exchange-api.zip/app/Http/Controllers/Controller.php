<?php

namespace App\Http\Controllers;

use App\Traits\Api\ApiResponses;

abstract class Controller
{
    use ApiResponses;
}
