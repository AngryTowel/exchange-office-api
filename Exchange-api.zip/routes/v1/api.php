<?php

require base_path('routes/v1/Authentication.php');
require base_path('routes/v1/User.php');
require base_path('routes/v1/Currencies.php');
require base_path('routes/v1/Forms.php');
require base_path('routes/v1/Organization.php');

